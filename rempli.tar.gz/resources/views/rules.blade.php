@extends('layouts.main')

@section('content')
<h1 style="text-align: center">Правила сайта</h1>
@endsection
