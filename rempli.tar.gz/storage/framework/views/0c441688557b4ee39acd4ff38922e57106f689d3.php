<?php if(count($actions) > 0): ?>
<form <?php echo $attributes; ?>>
    <?php echo e(csrf_field()); ?>


    <?php foreach($actions as $action): ?>
        <?php echo $action->render(); ?>

    <?php endforeach; ?>
</form>
<?php endif; ?>