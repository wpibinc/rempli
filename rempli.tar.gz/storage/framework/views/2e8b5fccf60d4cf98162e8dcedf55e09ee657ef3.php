<?php if($editable): ?>
	<a href="<?php echo e($editUrl); ?>" class="btn btn-primary btn-xs btn-flat" data-toggle="tooltip" title="<?php echo e(trans('sleeping_owl::lang.table.edit')); ?>">
		<i class="fa fa-pencil"></i>
	</a>
<?php endif; ?>
<?php if($deletable): ?>
	<form action="<?php echo e($deleteUrl); ?>" method="POST" style="display:inline-block;">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<input type="hidden" name="_method" value="DELETE" />
		<button class="btn btn-danger btn-xs btn-delete btn-flat" data-toggle="tooltip" title="<?php echo e(trans('sleeping_owl::lang.table.delete')); ?>">
			<i class="fa fa-trash"></i>
		</button>
	</form>
<?php endif; ?>
<?php if($restorable): ?>
	<form action="<?php echo e($restoreUrl); ?>" method="POST" style="display:inline-block;">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<button class="btn btn-warning btn-xs btn-flat" data-toggle="tooltip" title="<?php echo e(trans('sleeping_owl::lang.table.restore')); ?>">
			<i class="fa fa-reply"></i>
		</button>
	</form>
<?php endif; ?>
<?php if($destroyable): ?>
	<form action="<?php echo e($destroyUrl); ?>" method="POST" style="display:inline-block;">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<input type="hidden" name="_method" value="DELETE" />
		<button class="btn btn-danger btn-xs btn-destroy btn-flat" data-toggle="tooltip" title="<?php echo e(trans('sleeping_owl::lang.table.destroy')); ?>">
			<i class="fa fa-trash"></i>
		</button>
	</form>
<?php endif; ?>
