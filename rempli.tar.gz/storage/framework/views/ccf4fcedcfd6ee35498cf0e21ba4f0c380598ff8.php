<table <?php echo $attributes; ?>>
    <colgroup>
        <?php foreach($columns as $column): ?>
            <col width="<?php echo $column->getWidth(); ?>" />
        <?php endforeach; ?>
    </colgroup>
    <thead>
    <tr>
        <?php foreach($columns as $column): ?>
            <th <?php echo $column->getHeader()->htmlAttributesToString(); ?>>
                <?php echo $column->getHeader()->render(); ?>

            </th>
        <?php endforeach; ?>
    </tr>
    </thead>
    <tbody>
    <?php foreach($collection as $model): ?>
        <tr>
            <?php foreach($columns as $column): ?>
                <?php $column->setModel($model); ?>
                <td <?php echo $column->htmlAttributesToString(); ?>>
                    <?php echo $column->render(); ?>

                </td>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
    </tbody>

    <?php echo $__env->yieldContent('table.footer'); ?>
</table>

<?php if($collection instanceof \Illuminate\Contracts\Pagination\Paginator): ?>
    <div class="panel-footer">
        <?php echo (new \Illuminate\Pagination\BootstrapThreePresenter($collection))->render(); ?>

    </div>
<?php endif; ?>