
<?php if($order != null): ?>
    <table class="table table-striped">
    <?php foreach($order as $item): ?>

        <?php
        $avp = \App\AvProduct::where('id', $item->objectId)->first();
        $p = \App\Product::where('id', $item->objectId)->first();
        ?>
        <?php if($avp == null): ?>
            <tr>
                <td><?php echo e($p->price * $item->count); ?> руб.</td>
                <td><img src="<?php echo e($p->img); ?>" alt="" width="100px"></td>
                <td><?php echo e($p->product_name); ?></td>
                <td><?php echo e($item->count); ?> шт.</td>
                <td>Комментарий:<br> <?php echo e($item->comment); ?></td>
            </tr>
        <?php else: ?>
                <tr>
                    <td><?php echo e($item->count); ?> шт.</td>
                    <td><img src="http://av.ru<?php echo e($avp->image); ?>" alt="" width="100px"></td>
                    <td><?php echo e($avp->name); ?></td>
                    <td><?php echo e($avp->price * $item->count); ?> руб.</td>
                    <td>Комментарий:<br> <?php echo e($item->comment); ?></td>
                </tr>

        <?php endif; ?>
    <?php endforeach; ?>
    </table>
<?php endif; ?>
