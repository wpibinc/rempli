<?php $__env->startSection('content'); ?>
<?php foreach($errors->get('code') as $message): ?>
<p class="error"><?php echo e($message); ?></p>
<?php endforeach; ?>
    <?php echo e(Form::open(array('url' => '/confirm-code', 'method' => 'post'))); ?>

        <div class="form-group">
            <?php echo Form::label('Введите код'); ?>

            <?php echo Form::text('code', null,
                array('required',
                      'placeholder'=>'код')); ?>

        </div>
        <div class="form-group">
            <?php echo Form::submit('Отправить',
              array('class'=>'btn btn-primary')); ?>

        </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>