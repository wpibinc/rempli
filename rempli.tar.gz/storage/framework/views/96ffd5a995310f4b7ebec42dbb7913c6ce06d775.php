<?php foreach($children as $entry): ?>
    <li class="dd-item dd3-item <?php echo e($reorderable ? '' : 'dd3-not-reorderable'); ?>" data-id="<?php echo e($entry->id); ?>">
        <?php if($reorderable): ?>
            <div class="dd-handle dd3-handle"></div>
        <?php endif; ?>
        <div class="dd3-content">

            <?php if(is_callable($value)): ?>
                <?php echo $value($entry); ?>

            <?php else: ?>
                <?php echo e($entry->{$value}); ?>

            <?php endif; ?>

            <div class="pull-right">
                <?php foreach($controls as $control): ?>

                    <?php if($control instanceof \SleepingOwl\Admin\Contracts\ColumnInterface): ?>
                        <?php $control->setModel($entry); ?>
                    <?php endif; ?>

                    <?php echo $control->render(); ?>

                <?php endforeach; ?>
            </div>
        </div>
        <?php if($entry->children->count() > 0): ?>
            <ol class="dd-list">
                <?php echo $__env->make(AdminTemplate::getViewPath('display.tree_children'), ['children' => $entry->children], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ol>
        <?php endif; ?>
    </li>
<?php endforeach; ?>
