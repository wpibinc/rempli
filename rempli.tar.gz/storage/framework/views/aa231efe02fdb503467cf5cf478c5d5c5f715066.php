<div <?php echo $attributes; ?>>
    <div class="btn-group">
        <button
                type="submit"
                name="next_action"
                <?php if($showSaveAndCloseButton): ?>
                value="save_and_continue"
                <?php else: ?>
                value="save_and_close"
                <?php endif; ?>
                class="btn btn-primary btn-flat">
            <i class="fa fa-check"></i> <?php echo e($saveButtonText); ?>

        </button>
        <?php if($showSaveAndCloseButton or $showSaveAndCreateButton): ?>
            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-menu btn-actions">
                <div class="btn-group-vertical">
                    <?php if($showSaveAndCloseButton): ?>
                        <button type="submit" name="next_action" value="save_and_close" class="btn btn-success btn-block btn-flat">
                            <i class="fa fa-check"></i>
                            <?php echo e($saveAndCloseButtonText); ?>

                        </button>
                    <?php endif; ?>
                    <?php if($showSaveAndCreateButton): ?>
                        <div role="separator" class="divider"></div>
                        <button type="submit" name="next_action" value="save_and_create" class="btn btn-info btn-block btn-flat">
                            <i class="fa fa-check"></i>
                            <?php echo e($saveAndCreateButtonText); ?>

                        </button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if($showDeleteButton): ?>
        <button class="btn btn-delete btn-danger btn-flat" data-url="<?php echo $deleteUrl; ?>" data-redirect="<?php echo e($backUrl); ?>">
            <i class="fa fa-trash"></i> <?php echo e($deleteButtonText); ?>

        </button>
    <?php elseif($showRestoreButton): ?>
        <div class="btn-group">
            <button class="btn btn-restore btn-warning btn-flat" data-url="<?php echo $restoreUrl; ?>" data-redirect="<?php echo e($editUrl); ?>">
                <i class="fa fa-reply"></i> <?php echo e($restoreButtonText); ?>

            </button>
            <?php if($showDestroyButton): ?>
                <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-menu btn-actions">
                    <div class="btn-group-vertical">
                        <button class="btn btn-destroy btn-danger btn-flat" data-url="<?php echo $destroyUrl; ?>" data-redirect="<?php echo e($backUrl); ?>">
                            <i class="fa fa-trash"></i> <?php echo e($destroyButtonText); ?>

                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if($showCancelButton): ?>
        <a href="<?php echo e($backUrl); ?>" class="btn btn-link">
            <i class="fa fa-ban"></i> <?php echo e($cancelButtonText); ?>

        </a>
    <?php endif; ?>
</div>