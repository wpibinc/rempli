<p>
    Спасибо за регитрацию <?php echo e($fname); ?>

</p>

