<?php if($items instanceof \SleepingOwl\Admin\Form\Element\Columns): ?>
    <?php echo $items->render(); ?>

<?php else: ?>
<?php foreach($items as $item): ?>
    <?php if($item instanceof \Illuminate\Contracts\Support\Renderable): ?>
        <?php echo $item->render(); ?>

    <?php else: ?>
        <?php echo $item; ?>

    <?php endif; ?>
<?php endforeach; ?>
<?php endif; ?>