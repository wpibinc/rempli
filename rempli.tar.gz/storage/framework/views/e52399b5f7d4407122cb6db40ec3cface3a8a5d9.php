<?php $__env->startSection('title'); ?>

<?php $__env->startSection('style'); ?>
    @parent
    <link rel="stylesheet" type="text/css" href="css/order.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="jumbotron content">

            <h1 class="orderheader">Спасибо за заказ!</h1>

            <h2  id="successinfo">Ваш заказ был нами успешно получен. В ближайшие несколько минут, мы позвоним Вам для уточнения информации.</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>