<div class="col-md-12 categories">
    <?php foreach($categories as $category): ?>
    <a href="#" class="cats col-md-2 col-sm-6" data-id="<?php echo e($category['category_id']); ?>" id="<?php echo e($category['alias']); ?>">
        <img id="" class="" src="<?php echo e(asset($category['img'])); ?>" alt="<?php echo e($category['name']); ?>">
        <p><?php echo e($category['name']); ?></p>
    </a>
    <?php endforeach; ?>
    <br class="clear">
</div>