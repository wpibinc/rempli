<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
    <div class='reviews col-md-8 col-md-offset-2 col-sm-12 col-sm-offset-0'>
        <?php if(!empty($reviews)): ?>
            <?php foreach($reviews as $review): ?>
            <div class="review-item">
                <span class="title"><?php echo e($review->name); ?></span>
                <p class="content"><?php echo e($review->content); ?></p>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php echo e($reviews->render()); ?>

    </div>
    <div class="col-md-8 col-md-offset-2 col-sm-12 col-sm-offset-0">
        <?php if(Auth::user()): ?>
            <?php echo e(Form::open(array('url' => '/reviews', 'method' => 'post'))); ?>


            <div class="form-group">
                <?php echo Form::label('Ваш отзыв'); ?>

                <?php echo Form::textarea('message', null,
                    array('required',
                          'class'=>'form-control',
                          'placeholder'=>'отзыв')); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Отправить',
                  array('class'=>'btn btn-primary')); ?>

            </div>
            <?php echo e(Form::close()); ?>

        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>