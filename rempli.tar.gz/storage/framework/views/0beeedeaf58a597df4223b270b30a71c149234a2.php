<div <?php echo $attributes; ?>>
	<?php foreach($columns as $column): ?>
		<?php echo $column->render(); ?>

	<?php endforeach; ?>
</div>
