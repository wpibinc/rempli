<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Order;
use Auth;
use App\Adress;
use App\User;
use Flash;
use Mail;

class UserController extends Controller
{
    public function index(Request $request)
    {
        return view('order', ['user' => $user]);
    }
    
    public function myAccount(Request $request)
    {
        $user = Auth::user();
        $orders = Order::where('user_id', $user->id)->simplePaginate(15);
        $adresses = $user->adresses;
        return view('account', ['orders' => $orders, 'user' => $user, 'adresses' => $adresses]);
    }
    
    public function changeInfo(Request $request)
    {
        if(!$request->isXmlHttpRequest()){
            return abort(404);
        }
        $user = Auth::user();
        $action = $request->input('action');
        if($action == 'changepassword'){
            $pass = $request->input('pass');
            if(strlen($pass)< 6){
                return response()->json(['success' => false, 'message' => 'Длинна пароля - мин 6 символов']);
            }
            $user->password = bcrypt($request->input('pass'));
        }else{
            $email = $request->input('email');
            $phone = $request->input('phone');
            if($email != $user->email){
                $vUser = User::where('email', $email)->get();
                if(count($vUser)){
                    return response()->json(['success' => false, 'err'=> 'email', 'message' => 'email уже занят']);
                }
                $user->email = $email;
            }
            if($phone != $user->phone){
                $vUser = User::where('phone', $phone)->get();
                if(count($vUser)){
                    return response()->json(['success' => false, 'err'=> 'phone', 'message' => 'телефон уже занят']);
                }
            }
            $user->fname = $request->input('fname');
            $user->sname = $request->input('sname');
        }

        $user->save();
        return response()->json(['success' => true]);
    }
    
    public function addAdress(Request $request)
    {
        if(!$request->isXmlHttpRequest()){
            return abort(404);
        }
        $user = Auth::user();
        $adress = new Adress();
        $adress->user_id = $user->id;
        $adress->street = $request->input('street');
        $adress->home = $request->input('home');
        $adress->korp = $request->input('korp');
        $adress->flat = $request->input('flat');
        $adress->save();
        return response()->json(['success' => true]);
    }
    
    public function deleteAdress(Request $request)
    {
        if(!$request->isXmlHttpRequest()){
            return abort(404);
        }
        $id = $request->input('id');
        Adress::destroy($id);
        return response()->json(['success' => true]);
    }
    
    public function getOrderDetails(Request $request)
    {
        if(!$request->isXmlHttpRequest()){
            return abort(404);
        }
        $id = $request->input('id');
        $items = Order::find($id)->items()->get();
        $output = '';
        if($items->count()){
            foreach($items as $item){
                $item->getRelations();
                if($item->product){
                    $output .= '<div class="item"><div class="info"><span class="title">'.$item->product->product_name.'</span><span class="count">'.$item->count.' шт</span><spav class="price">'.$item->product->price.'</span></div><div class="img"><img src="'.$item->product->img.'"></div></div>';
                    
                }
                if($item->avproduct){
                    $output .= '<div class="item"><div class="info"><span class="title">'.$item->avproduct->name.'</span><span class="count">'.$item->count.' шт</span><spav class="price">'.$item->avproduct->price.'</span></div><div class="img"><img src="http://av.ru'.$item->avproduct->image.'"></div></div>';
                }
            }
        }
        echo $output;
        die();
    }
    
    public function confirmCode(Request $request)
    {
        if($request->isMethod('POST')){
            $this->validate($request, [
                'code' => 'required|min:4|max:4|exists:users,confirmation_code',
            ]);
            $user = User::where('confirmation_code', $request->input('code'))->first();
            $user->confirmed = 1;
            $user->confirmation_code = null;
            $user->save();
            $request->session()->flash('success', 'Код принят. Вы можете войти');
            Mail::send('emails.register', array('fname' => $user->fname), function($message) use ($user)
        {
            $message->to($user->email, $user->fname.' '.$user->sname)->subject('Регистрация прошла успешно. ');
        });
            return redirect('/login');
        }
        return view('auth.confirmcode');
    }
}

