<?php

namespace App;


class Order2 extends Order
{

}
