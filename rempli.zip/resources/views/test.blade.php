<pre>
<?php 
    var_dump($count);
//    foreach($orders as $order){
//        var_dump($order->id);
//    }
?>
</pre>

