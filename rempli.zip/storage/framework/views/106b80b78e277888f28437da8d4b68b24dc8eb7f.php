<?php foreach($pages as $page): ?>
    <?php echo $page->render(); ?>

<?php endforeach; ?>