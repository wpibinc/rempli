<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Войти или <a href="/register">Зарегистрироваться</a></div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">


                            <input id="phone" type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Телефон">

                            <?php if($errors->has('phone')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                            <?php endif; ?>

                        </div>

                        <?php /*<div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">*/ ?>


                                <?php /*<input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Логин">*/ ?>

                                <?php /*<?php if($errors->has('username')): ?>*/ ?>
                                    <?php /*<span class="help-block">*/ ?>
                                        <?php /*<strong><?php echo e($errors->first('username')); ?></strong>*/ ?>
                                    <?php /*</span>*/ ?>
                                <?php /*<?php endif; ?>*/ ?>

                        <?php /*</div>*/ ?>

                        <?php /*<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">*/ ?>
                            <?php /*<label for="email" class="col-md-4 control-label">E-Mail Address</label>*/ ?>

                            <?php /*<div class="col-md-6">*/ ?>
                                <?php /*<input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">*/ ?>

                                <?php /*<?php if($errors->has('email')): ?>*/ ?>
                                    <?php /*<span class="help-block">*/ ?>
                                        <?php /*<strong><?php echo e($errors->first('email')); ?></strong>*/ ?>
                                    <?php /*</span>*/ ?>
                                <?php /*<?php endif; ?>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <input id="password" type="password" class="form-control" name="password" placeholder="Пароль">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>

                        <?php /*<div class="form-group">*/ ?>
                                <?php /*<div class="checkbox">*/ ?>
                                    <?php /*<label>*/ ?>
                                        <?php /*<input type="checkbox" name="remember"> Запомнить*/ ?>
                                    <?php /*</label>*/ ?>
                                <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>

                        <div class="form-group">
                            <button type="submit" class="btn-signin btn btn-primary btn-block" id="loginButton">Вход</button>
                                <?php /*<a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>                           */ ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    jQuery(function($){
        $("#phone").mask("+7 (999) 999-9999");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>