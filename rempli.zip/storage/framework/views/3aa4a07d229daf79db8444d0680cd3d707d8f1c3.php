<?php if( ! empty($title)): ?>
	<div class="row">
		<div class="col-lg-12">
			<h2 class="page-title"><small><?php echo e($title); ?></small></h2>
		</div>
	</div>
<?php endif; ?>

<?php echo $__env->yieldContent('before.panel'); ?>

<div class="panel panel-default">
	<div class="panel-heading">
		<?php if($creatable): ?>
			<a href="<?php echo e(url($createUrl)); ?>" class="btn btn-primary btn-flat">
				<i class="fa fa-plus"></i> <?php echo e(trans('sleeping_owl::lang.table.new-entry')); ?>

			</a>
		<?php endif; ?>

			<?php echo $__env->yieldContent('panel.buttons'); ?>

			<div class="pull-right">
				<?php echo $__env->yieldContent('panel.heading.actions'); ?>
			</div>
	</div>

	<?php echo $__env->yieldContent('panel.heading'); ?>

	<?php foreach($extensions as $ext): ?>
		<?php echo $ext->render(); ?>

	<?php endforeach; ?>

	<?php echo $__env->yieldContent('panel.footer'); ?>
</div>

<?php echo $__env->yieldContent('after.panel'); ?>
