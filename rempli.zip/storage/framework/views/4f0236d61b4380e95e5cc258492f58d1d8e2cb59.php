<form <?php echo $attributes; ?>>

    <input type="hidden" name="_redirectBack" value="<?php echo e($backUrl); ?>" />
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

    <?php echo $__env->make(AdminTemplate::getViewPath('form.partials.elements'), ['items' => $items], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $buttons->render(); ?>

</form>
