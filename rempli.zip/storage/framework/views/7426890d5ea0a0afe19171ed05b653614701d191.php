<table <?php echo $attributes; ?>>
    <colgroup>
        <?php foreach($columns as $column): ?>
            <col width="<?php echo $column->getWidth(); ?>" />
        <?php endforeach; ?>
    </colgroup>
    <thead>
    <tr>
        <?php foreach($columns as $column): ?>
            <th <?php echo $column->getHeader()->htmlAttributesToString(); ?>>
                <?php echo $column->getHeader()->render(); ?>

            </th>
        <?php endforeach; ?>
    </tr>
    </thead>
    <?php echo $__env->yieldContent('table.footer'); ?>
</table>