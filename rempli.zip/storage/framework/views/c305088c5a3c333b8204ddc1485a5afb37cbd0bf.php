<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>
            Сколько стоит
        </h1>
        <p>
            Мы в Rempli долго думали над тем, как сделать доставку наиболее простой и выгодной для Вас. Для этого мы разработали наиболее прозрачные условия оплаты наших услуг. Вы не переплачиваете за продукты, нет никаких сложных процентов за доставку, все просто:
            <br>
            Сумма заказа - стоимость продуктов по чеку магазина + стоимость доставки.
            <br>
            Стоимость доставки в Rempli:<br>
            - 500р. – при любом заказе до 8кг.<br>
            - 800р. – при любом заказе свыше 8кг.

        </p>

        <nav>
            <ul class="pager">

                <li class="previous"><a id="backToMain" href="/" class="backForth">
                        <span aria-hidden="true">&larr;</span> На главную</a>
                </li>


            </ul>
        </nav>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>