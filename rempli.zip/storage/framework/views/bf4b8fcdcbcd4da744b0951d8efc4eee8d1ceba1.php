<tfoot <?php echo $attributes; ?>>
    <tr>
        <?php foreach($filters as $index => $filter): ?>
            <td data-index="<?php echo e($index); ?>">
                <?php echo $filter; ?>

            </td>
        <?php endforeach; ?>
    </tr>
</tfoot>