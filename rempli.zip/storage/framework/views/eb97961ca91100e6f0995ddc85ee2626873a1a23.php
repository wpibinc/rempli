<div class="form-group <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
	<label for="<?php echo e($name); ?>" class="control-label">
		<?php echo e($label); ?>


		<?php if($required): ?>
			<span class="text-danger">*</span>
		<?php endif; ?>
	</label>
	<textarea class="form-control"
			  rows="<?php echo e($rows); ?>"
			  name="<?php echo e($name); ?>"
			  <?php if($readonly): ?> readonly <?php endif; ?>
	><?php echo $value; ?></textarea>
	<?php echo $__env->make(AdminTemplate::getViewPath('form.element.errors'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>