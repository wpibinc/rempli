<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Зарегистрироваться или <a href="/login">Войти</a></div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <?php /*<div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">*/ ?>
                                <?php /*<input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Логин">*/ ?>
                                <?php /*<?php if($errors->has('username')): ?>*/ ?>
                                    <?php /*<span class="help-block">*/ ?>
                                        <?php /*<strong><?php echo e($errors->first('username')); ?></strong>*/ ?>
                                    <?php /*</span>*/ ?>
                                <?php /*<?php endif; ?>*/ ?>
                        <?php /*</div>*/ ?>

                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                            <input id="phone" type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Телeфон">
                            <?php if($errors->has('phone')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
                            <input id="fname" type="text" class="form-control" name="fname" value="<?php echo e(old('fname')); ?>" placeholder="Имя">
                            <?php if($errors->has('fname')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('fname')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('sname') ? ' has-error' : ''); ?>">
                            <input id="sname" type="text" class="form-control" name="sname" value="<?php echo e(old('sname')); ?>" placeholder="Фамилия">
                            <?php if($errors->has('sname')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('sname')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input id="password" type="password" class="form-control" name="password"  placeholder="Пароль">
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Пароль повторно">
                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn-signin btn btn-primary btn-block" id="loginButton">Зарегистрироваться</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    jQuery(function($){
        $("#phone").mask("+7 (999) 999-9999");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>