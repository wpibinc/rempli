<div class="col-md-12 categories">
    <?php foreach($categories as $category): ?>
    <a href="#" class="cats" data-id="<?php echo e($category['category_id']); ?>" id="<?php echo e($category['alias']); ?>"><img id="" class="col-md-2 col-sm-6" src="<?php echo e($category['img']); ?>" alt="<?php echo e($category['name']); ?>"></a>
    <?php endforeach; ?>
    <br class="clear">
</div>