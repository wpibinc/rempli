<?php if( ! is_null($value)): ?>
	<a href="<?php echo e($url); ?>" class="btn btn-xs btn-default pull-right">
		<i class="<?php echo e($icon); ?>" data-toggle="tooltip" title="<?php echo e($title); ?>"></i>
	</a>
<?php endif; ?>
