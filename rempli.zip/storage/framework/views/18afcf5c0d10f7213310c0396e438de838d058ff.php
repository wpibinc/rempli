<script type="text/javascript">
    $(function () {
        $('.nestable').nestable({
            maxDepth: 20
        }).on('change', function (e) {
            var url = $(this).data('url');
            var list = e.length ? e : $(e.target);
            var data = list.nestable('serialize');
            $.post(url, {data: data});
        });
    })
</script>

<div class="panel panel-default">
    <div class="panel-heading">
        <?php if($creatable): ?>
            <a class="btn btn-primary" href="<?php echo e($createUrl); ?>">
                <i class="fa fa-plus"></i> <?php echo e(trans('sleeping_owl::lang.table.new-entry')); ?>

            </a>
        <?php endif; ?>
    </div>

    <div class="panel-body">
        <div class="dd nestable" data-url="<?php echo e($url); ?>/reorder">
            <ol class="dd-list">
                <?php echo $__env->make(AdminTemplate::getViewPath('display.tree_children'), ['children' => $items], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ol>
        </div>
    </div>
</div>

