<select class="form-control column-filter" data-type="select">
	<option value="">- <?php echo e($placeholder); ?> -</option>
	<?php foreach($options as $key => $option): ?>
		<option value="<?php echo e($key); ?>"><?php echo e($option); ?></option>
	<?php endforeach; ?>
</select>
