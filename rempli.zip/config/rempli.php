<?php
return [

    'title'         => 'Доставка продуктов за 1 час',

    'copyright'     => 'Rempli &copy; 2015-'.Carbon\Carbon::now()->format('Y'),
    'copy_start'    => 2015,
    'copy_end'      => Carbon\Carbon::now()->year

];